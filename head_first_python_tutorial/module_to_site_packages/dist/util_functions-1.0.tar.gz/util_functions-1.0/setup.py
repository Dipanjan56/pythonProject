from setuptools import setup

setup(
    name='util_functions',
    version='1.0',
    description='The Head First Python Utility tools',
    author='Dipanjan Kundu',
    author_email='dipanjan56@gmail.com',
    url='headfirstlabs.com',
    py_modules=['util_functions']
)
